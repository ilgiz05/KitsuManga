package com.example.domain.models.anime

data class LinksModel(
    val self: String,
)