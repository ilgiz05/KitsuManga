package com.example.domain.models.anime

data class CategoriesModel(
    val links: LinksXXModel
)