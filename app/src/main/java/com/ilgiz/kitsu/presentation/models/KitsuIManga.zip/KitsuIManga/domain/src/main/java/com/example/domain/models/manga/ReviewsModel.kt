package com.example.domain.models.manga

data class ReviewsModel(
    val links:
    LinksXXXXXXModel,
    )