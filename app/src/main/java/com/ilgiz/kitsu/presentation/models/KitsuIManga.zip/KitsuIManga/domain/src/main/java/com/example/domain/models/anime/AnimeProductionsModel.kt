package com.example.domain.models.anime

data class AnimeProductionsModel(
    val links: LinksXXXXXXXXXXModel
)