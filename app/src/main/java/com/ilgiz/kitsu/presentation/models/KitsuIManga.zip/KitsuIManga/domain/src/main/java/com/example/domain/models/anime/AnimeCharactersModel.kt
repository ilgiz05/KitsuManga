package com.example.domain.models.anime

data class AnimeCharactersModel(
    val links: LinksXXXXXXXXXXXModel
)