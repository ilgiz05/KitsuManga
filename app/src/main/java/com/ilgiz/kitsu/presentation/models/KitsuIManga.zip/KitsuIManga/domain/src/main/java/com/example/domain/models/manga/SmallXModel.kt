package com.example.domain.models.manga

data class SmallXModel(
    val width: Int?,
    val height: Int?,
)