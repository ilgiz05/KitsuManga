package com.example.domain.models.anime

data class MediumModel(
    val width: Int?,
    val height: Int?,
)