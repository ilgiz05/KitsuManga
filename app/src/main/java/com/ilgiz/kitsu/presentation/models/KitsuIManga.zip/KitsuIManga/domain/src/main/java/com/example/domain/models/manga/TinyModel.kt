package com.example.domain.models.manga

data class TinyModel(
    val width: Int?,
    val height: Int?
)