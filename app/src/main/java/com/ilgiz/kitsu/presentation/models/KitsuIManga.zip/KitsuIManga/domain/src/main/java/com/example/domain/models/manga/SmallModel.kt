package com.example.domain.models.manga

data class SmallModel(
    val width: Int?,
    val height: Int?,
)