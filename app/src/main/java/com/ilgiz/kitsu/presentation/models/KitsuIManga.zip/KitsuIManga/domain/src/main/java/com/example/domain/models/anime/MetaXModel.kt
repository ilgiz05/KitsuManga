package com.example.domain.models.anime

data class MetaXModel(
    val dimensionsXModel: DimensionsXModel
)