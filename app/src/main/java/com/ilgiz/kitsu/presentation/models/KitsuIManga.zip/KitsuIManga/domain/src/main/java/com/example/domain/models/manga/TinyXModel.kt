package com.example.domain.models.manga

data class TinyXModel(
    val width: Int?,
    val height: Int?,
)