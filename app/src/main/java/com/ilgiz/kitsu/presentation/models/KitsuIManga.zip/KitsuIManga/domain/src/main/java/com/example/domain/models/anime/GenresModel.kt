package com.example.domain.models.anime

data class GenresModel(
    val linksXModel: LinksXModel,
)