package com.example.domain.models.manga

data class LinksXXXXXXXXXXModel(
    val self: String,
    val related: String,
)