package com.example.domain.models.anime

data class ReviewsModel(
    val links: LinksXXXXXXModel,
)