package com.example.domain.models.manga

data class LinksModel(
    val self: String,
)