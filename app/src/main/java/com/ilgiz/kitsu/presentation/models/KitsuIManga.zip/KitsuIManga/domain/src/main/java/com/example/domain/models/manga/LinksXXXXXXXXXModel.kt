package com.example.domain.models.manga

data class LinksXXXXXXXXXModel(
    val self: String,
    val related: String,
)