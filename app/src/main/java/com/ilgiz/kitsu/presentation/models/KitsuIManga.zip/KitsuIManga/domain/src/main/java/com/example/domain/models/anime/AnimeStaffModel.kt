package com.example.domain.models.anime

data class AnimeStaffModel(
    val links: LinksXXXXXXXXXXXXModel
)