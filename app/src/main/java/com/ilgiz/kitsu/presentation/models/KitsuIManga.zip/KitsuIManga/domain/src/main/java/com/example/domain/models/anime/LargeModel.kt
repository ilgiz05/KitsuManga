package com.example.domain.models.anime

data class LargeModel(
    val width: Int?,
    val height: Int?
)