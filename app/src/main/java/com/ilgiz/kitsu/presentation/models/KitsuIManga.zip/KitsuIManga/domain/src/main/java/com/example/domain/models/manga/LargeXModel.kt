package com.example.domain.models.manga

data class LargeXModel(
    val width: Int?,
    val height: Int?,
)