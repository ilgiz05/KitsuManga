package com.example.domain.models.manga

data class MangaCharactersModel(
    val links: LinksXXXXXXXXXModel,
)