package com.example.domain.models.manga

data class LinksXXXXXModel(
    val self: String,
    val related: String,
)