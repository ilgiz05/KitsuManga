package com.example.domain.models.anime

data class LinksXXXXXXXXXXXXXModel(
    val first: String,
    val prev: String?,
    val next: String,
    val last: String
)