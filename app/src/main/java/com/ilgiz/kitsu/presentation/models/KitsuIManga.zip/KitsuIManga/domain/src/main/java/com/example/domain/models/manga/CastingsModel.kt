package com.example.domain.models.manga

data class CastingsModel(
    val links: LinksXXXModel,
)