package com.example.domain.models.genres

data class LinksModel(
    val last: String,
    val first: String,
)