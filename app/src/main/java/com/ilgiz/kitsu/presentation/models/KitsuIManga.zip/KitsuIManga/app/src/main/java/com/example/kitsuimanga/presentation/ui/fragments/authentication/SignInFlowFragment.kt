package com.example.kitsuimanga.presentation.ui.fragments.authentication

import com.example.kitsuimanga.R
import com.example.kitsuimanga.base.BaseFlowFragment

class SignInFlowFragment :
    BaseFlowFragment(R.layout.fragment_sign_in_flow, R.id.nav_host_sign_in_fragment)