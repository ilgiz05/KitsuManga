package com.example.domain.models.manga

data class CategoriesModel(
    val links: LinksXXModel
)