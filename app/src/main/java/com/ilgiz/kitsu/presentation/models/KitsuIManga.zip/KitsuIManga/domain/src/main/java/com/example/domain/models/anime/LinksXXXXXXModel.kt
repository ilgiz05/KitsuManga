package com.example.domain.models.anime

data class LinksXXXXXXModel(
    val self: String,
    val related: String
)