package com.example.domain.models.anime

data class MediaRelationshipsModel(
    val links: LinksXXXXXXXModel
)