package com.example.domain.models.manga

data class LinksXXXXModel(
    val self: String,
    val related: String
)