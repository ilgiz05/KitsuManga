package com.example.domain.models.anime

data class CastingsModel(
    val links: LinksXXXModel
)