package com.example.domain.models.manga

data class MetaXModel(
    val dimensionsXModel: DimensionsXModel,
)