package com.example.domain.models.genres

data class AttributesModels(
    val createdAt: String,
    val name: String,
    val description: String,
    val slug: String,
    val updatedAt: String,
)