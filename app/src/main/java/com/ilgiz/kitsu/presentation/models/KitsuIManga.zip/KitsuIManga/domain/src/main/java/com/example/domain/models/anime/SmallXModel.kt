package com.example.domain.models.anime

data class SmallXModel(
    val width: Int?,
    val height: Int?
)