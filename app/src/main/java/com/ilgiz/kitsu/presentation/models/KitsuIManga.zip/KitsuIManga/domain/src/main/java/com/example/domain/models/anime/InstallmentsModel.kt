package com.example.domain.models.anime

data class InstallmentsModel(
    val links: LinksXXXXModel
)