package com.example.domain.models.anime

data class EpisodesModel(
    val links: LinksXXXXXXXXModel
)