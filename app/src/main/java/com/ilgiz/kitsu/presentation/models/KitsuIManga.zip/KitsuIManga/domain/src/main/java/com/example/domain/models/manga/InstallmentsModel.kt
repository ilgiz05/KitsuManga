package com.example.domain.models.manga

data class InstallmentsModel(
    val links: LinksXXXXModel,
)