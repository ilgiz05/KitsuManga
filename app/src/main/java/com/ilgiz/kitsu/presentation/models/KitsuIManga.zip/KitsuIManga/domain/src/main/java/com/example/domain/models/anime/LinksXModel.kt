package com.example.domain.models.anime

data class LinksXModel(
    val self: String,
    val related: String,
)