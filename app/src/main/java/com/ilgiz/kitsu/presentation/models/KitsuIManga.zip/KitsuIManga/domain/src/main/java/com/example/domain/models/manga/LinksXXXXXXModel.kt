package com.example.domain.models.manga

data class LinksXXXXXXModel(
    val self: String,
    val related: String,
)