package com.example.domain.models.manga

data class LinksXXXXXXXModel(
    val self: String,
    val related: String
)