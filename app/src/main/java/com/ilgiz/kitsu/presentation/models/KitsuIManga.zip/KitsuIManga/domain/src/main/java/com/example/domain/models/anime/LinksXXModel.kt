package com.example.domain.models.anime

data class LinksXXModel(
    val self: String,
    val related: String
)