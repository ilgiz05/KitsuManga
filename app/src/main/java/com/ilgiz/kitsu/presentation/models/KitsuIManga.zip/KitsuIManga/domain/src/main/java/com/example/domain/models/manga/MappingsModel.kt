package com.example.domain.models.manga

data class MappingsModel(
    val links: LinksXXXXXModel,
)