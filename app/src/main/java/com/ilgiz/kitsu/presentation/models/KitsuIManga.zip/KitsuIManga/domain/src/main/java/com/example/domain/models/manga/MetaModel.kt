package com.example.domain.models.manga

data class MetaModel(
    val dimensionsModel: DimensionsModel,
)