package com.example.kitsuimanga.base

interface BaseDiffModel {
    val id: Any?
    override fun equals(other: Any?): Boolean
}