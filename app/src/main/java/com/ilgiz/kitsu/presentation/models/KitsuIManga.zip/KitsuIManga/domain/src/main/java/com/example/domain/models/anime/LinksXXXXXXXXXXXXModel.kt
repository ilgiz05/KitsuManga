package com.example.domain.models.anime

data class LinksXXXXXXXXXXXXModel(
    val self: String,
    val related: String
)