package com.example.domain.models.anime

data class SmallModel(
    val width: Int?,
    val height: Int?,
)