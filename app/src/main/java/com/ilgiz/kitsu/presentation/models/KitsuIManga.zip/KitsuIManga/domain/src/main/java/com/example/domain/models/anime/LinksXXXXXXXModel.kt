package com.example.domain.models.anime

data class LinksXXXXXXXModel(
    val self: String,
    val related: String
)