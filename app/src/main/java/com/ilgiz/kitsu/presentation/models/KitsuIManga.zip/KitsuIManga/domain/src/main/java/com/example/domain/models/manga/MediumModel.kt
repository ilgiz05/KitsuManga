package com.example.domain.models.manga

data class MediumModel(
    val width: Int?,
    val height: Int?,
)