package com.example.domain.models.anime

data class MappingsModel(
    val links: LinksXXXXXModel
)