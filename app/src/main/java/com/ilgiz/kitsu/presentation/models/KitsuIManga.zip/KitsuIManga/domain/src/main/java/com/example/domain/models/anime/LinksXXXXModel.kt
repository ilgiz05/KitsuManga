package com.example.domain.models.anime

data class LinksXXXXModel(
    val self: String,
    val related: String
)