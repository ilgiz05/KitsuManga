package com.example.domain.models.anime

data class MetaXXModel(
    val count: Int,
)