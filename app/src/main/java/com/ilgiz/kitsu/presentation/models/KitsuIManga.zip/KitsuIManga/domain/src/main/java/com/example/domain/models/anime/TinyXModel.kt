package com.example.domain.models.anime

data class TinyXModel(
    val width: Int?,
    val height: Int?
)