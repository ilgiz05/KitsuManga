package com.example.domain.models.manga

data class TitlesModel(
    val en: String?,
    val enJp: String?,
    val jaJp: String?,
)