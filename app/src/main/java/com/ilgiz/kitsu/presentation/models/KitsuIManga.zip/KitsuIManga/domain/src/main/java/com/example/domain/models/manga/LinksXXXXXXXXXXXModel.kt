package com.example.domain.models.manga

data class LinksXXXXXXXXXXXModel(
    val first: String,
    val prev: String?,
    val next: String,
    val last: String,
)