package com.example.domain.models.anime

data class LinksXXXXXXXXXXXModel(
    val self: String,
    val related: String
)