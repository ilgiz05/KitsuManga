package com.example.domain.models.genres

data class MetaModel(val count: Int = 0)