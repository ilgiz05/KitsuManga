package com.example.domain.models.anime

data class LinksXXXXXXXXXModel(
    val self: String,
    val related: String,
)