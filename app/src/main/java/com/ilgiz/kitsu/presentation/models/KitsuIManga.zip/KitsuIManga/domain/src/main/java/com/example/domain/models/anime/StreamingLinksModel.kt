package com.example.domain.models.anime

data class StreamingLinksModel(
    val links: LinksXXXXXXXXXModel
)