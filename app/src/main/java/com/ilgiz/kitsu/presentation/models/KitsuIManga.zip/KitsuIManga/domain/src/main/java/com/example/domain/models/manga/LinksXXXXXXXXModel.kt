package com.example.domain.models.manga

data class LinksXXXXXXXXModel(
    val self: String,
    val related: String,
)