package com.example.domain.models.anime

data class MetaModel(
    val dimensionsModel: DimensionsModel,
)