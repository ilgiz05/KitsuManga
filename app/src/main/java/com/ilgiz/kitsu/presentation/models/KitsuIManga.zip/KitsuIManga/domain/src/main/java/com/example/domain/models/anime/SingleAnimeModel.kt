package com.example.domain.models.anime

data class SingleAnimeModel(
    val data: AnimeDataModel
)