package com.example.domain.models.manga

data class ChaptersModel(
    val links: LinksXXXXXXXXModel,
)