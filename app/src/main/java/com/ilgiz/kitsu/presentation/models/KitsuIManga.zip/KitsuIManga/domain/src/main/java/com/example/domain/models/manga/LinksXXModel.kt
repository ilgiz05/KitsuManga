package com.example.domain.models.manga

data class LinksXXModel(
    val self: String,
    val related: String,
)