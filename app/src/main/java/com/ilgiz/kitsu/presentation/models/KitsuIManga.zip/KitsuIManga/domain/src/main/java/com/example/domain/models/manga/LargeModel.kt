package com.example.domain.models.manga

data class LargeModel(
    val width: Int?,
    val height: Int?,
)