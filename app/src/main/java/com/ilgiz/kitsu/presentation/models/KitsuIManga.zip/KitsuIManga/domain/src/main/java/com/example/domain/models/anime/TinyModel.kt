package com.example.domain.models.anime

data class TinyModel(
    val width: Int?,
    val height: Int?,
)