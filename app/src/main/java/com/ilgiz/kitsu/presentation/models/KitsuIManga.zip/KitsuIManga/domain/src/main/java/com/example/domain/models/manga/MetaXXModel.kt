package com.example.domain.models.manga

data class MetaXXModel(
    val count: Int,
)