package com.example.domain.models.anime

data class TitlesModel(
    val en: String?,
    val enJp: String?,
    val jaJp: String?,
)