package com.example.domain.models.manga

data class GenresModel(
    val links: LinksXModel
)