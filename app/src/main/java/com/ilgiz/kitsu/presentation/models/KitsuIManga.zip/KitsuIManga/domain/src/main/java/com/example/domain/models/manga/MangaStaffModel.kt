package com.example.domain.models.manga

data class MangaStaffModel(
    val links: LinksXXXXXXXXXXModel,
)