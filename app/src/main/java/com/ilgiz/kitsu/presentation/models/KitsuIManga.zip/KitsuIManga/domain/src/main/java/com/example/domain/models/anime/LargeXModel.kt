package com.example.domain.models.anime

data class LargeXModel(
    val width: Int?,
    val height: Int?
)