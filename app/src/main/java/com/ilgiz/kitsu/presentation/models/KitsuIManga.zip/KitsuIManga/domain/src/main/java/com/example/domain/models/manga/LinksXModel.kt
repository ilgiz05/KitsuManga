package com.example.domain.models.manga

data class LinksXModel(
    val self: String,
    val related: String,
)