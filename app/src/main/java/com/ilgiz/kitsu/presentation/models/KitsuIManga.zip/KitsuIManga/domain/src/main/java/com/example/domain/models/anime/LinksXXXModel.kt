package com.example.domain.models.anime

data class LinksXXXModel(
    val self: String,
    val related: String
)